import React from 'react';
import CsvUploader from './CsvUploader';



const App = () => {
  return (
    <div>
      
     
      <CsvUploader/>
      {/* <CSVFileUploader/> */}
    </div>
  );
};

export default App;