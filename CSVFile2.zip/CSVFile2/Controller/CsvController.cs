﻿// CSVController.cs

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSVFileDAL;
using CSVFileDAL.Models;
using CSVFileUpload.DTO;
using CSVFileUpload.Hubs;
using CSVFileUpload.Services;

[ApiController]
[Route("[controller]")]
public class CSVController : ControllerBase
{
    private readonly ICSVService _csvService;
    private readonly IHubContext<ProgressHub> _hubContext;
    private readonly IEntityRepository _entityRepository;

    public CSVController(ICSVService csvService, IHubContext<ProgressHub> hubContext, IEntityRepository entityRepository)
    {
        _csvService = csvService;
        _entityRepository = entityRepository;
        _hubContext = hubContext;
    }

    [HttpPost("upload")]
    public async Task<IActionResult> GetEmployeeCSV([FromForm] IFormFileCollection files)
    {
        try
        {
            var entities = _csvService.ReadCSV<EntityTbl>(files[0].OpenReadStream());
            var totalEntities = entities.Count();
            var progress = new Progress<int>(value =>
            {
                Console.WriteLine($"Progress: {value}%");
            });

            await ProcessCSVWithProgress(entities, progress);

            await _entityRepository.AddEntities(entities);

            return Ok(entities);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred while processing the file: {ex}");
            return StatusCode(500, "An error occurred while processing the file.");
        }
    }

    private async Task ProcessCSVWithProgress(IEnumerable<EntityTbl> entities, IProgress<int> progress)
    {
        int totalSteps = entities.Count();
        int currentStep = 0;

        foreach (var entity in entities)
        {
            // Simulate processing each entity by printing its name to the console
            Console.WriteLine($"Processing entity: {entity.EntityName}");

            // Simulate a slower progression by introducing a delay
            await Task.Delay(1000);

            // Update progress
            currentStep++;
            int currentProgress = currentStep * 100 / totalSteps;

            // Report progress
            progress.Report(currentProgress);

            // Send progress updates to SignalR hub
            await _hubContext.Clients.All.SendAsync("ReceiveProgress", currentProgress);
        }
    }

}
