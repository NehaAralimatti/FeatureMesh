﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSVFileDAL;
using CSVFileDAL.Models;
using CSVFileUpload.DTO;
using CSVFileUpload.Hubs;
using CSVFileUpload.Services;

[ApiController]
[Route("[controller]")]
public class CSVController : ControllerBase
{
    private readonly ICSVService _csvService;
    private readonly IHubContext<ProgressHub> _hubContext;
    private readonly IEntityRepository _entityRepository;

    public CSVController(ICSVService csvService, IHubContext<ProgressHub> hubContext, IEntityRepository entityRepository)
    {
        _csvService = csvService;
        _entityRepository = entityRepository;
        _hubContext = hubContext;
    }

    [HttpPost("upload")]
    public async Task<IActionResult> GetEmployeeCSV([FromForm] IFormFileCollection files)
    {
        try
        {
            var entities = _csvService.ReadCSV<EntityTbl>(files[0].OpenReadStream());
            var totalEntities = entities.Count();
            var progress = new Progress<int>(value =>
            {
                Console.WriteLine($"Progress: {value}%");
            });

            await ProcessCSVWithProgress(entities, progress);

            await _entityRepository.AddEntities(entities);

            return Ok(entities);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred while processing the file: {ex}");
            return StatusCode(500, "An error occurred while processing the file.");
        }
    }

    private async Task ProcessCSVWithProgress(IEnumerable<EntityTbl> entities, IProgress<int> progress)
    {
        int totalSteps = entities.Count();
        int currentStep = 0;

        foreach (var entity in entities)
        {
            
            Console.WriteLine($"Processing entity: {entity.EntityName}");

            
            await Task.Delay(1000);

            
            currentStep++;
            int currentProgress = currentStep * 100 / totalSteps;

            
            progress.Report(currentProgress);

            
            await _hubContext.Clients.All.SendAsync("ReceiveProgress", currentProgress);
        }
    }

    //private async Task CallApiAsync(IEnumerable<EntityTbl> entities, IProgress<int> progress)
    //{
    //    string baseApiUrl = "https://featuremarketplacewebapiforcrud.azurewebsites.net/api/Feature/AddFeature"; // Replace with your API endpoint

    //    using (var httpClient = new HttpClient())
    //    {
    //        httpClient.BaseAddress = new Uri(baseApiUrl);
    //        httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

    //        try
    //        {
    //            int totalSteps = entities.Count();
    //            int currentStep = 0;

    //            foreach (var entity in entities)
    //            {
    //                var entityAddRequest = new EntityAddRequest
    //                {
    //                    EntityName = entity.EntityName,
    //                    Description = entity.Description,
    //                    FeatureName = entity.FeatureName,
    //                    FeatureDataType = entity.FeatureDataType,
    //                    FeatureValue = entity.FeatureValue,
    //                    
    //                };

    //                var jsonPayload = Newtonsoft.Json.JsonConvert.SerializeObject(entityAddRequest);
    //                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

    //                var response = await httpClient.PostAsync(baseApiUrl, content);

    //                int currentProgress = (currentStep + 1) * 100 / totalSteps;

    //                if (!response.IsSuccessStatusCode)
    //                {
    //                    Console.WriteLine($"API call failed for entity {entity.EntityName}. Status code: {response.StatusCode}, Reason: {response.ReasonPhrase}");

    //                    var responseContent = await response.Content.ReadAsStringAsync();
    //                    Console.WriteLine($"Response content: {responseContent}");

    //                    progress.Report(currentProgress);
    //                    continue;
    //                }

    //                progress.Report(currentProgress);

    //                currentStep++;
    //            }
    //        }
    //        catch (HttpRequestException ex)
    //        {
    //            Console.WriteLine($"An HTTP request error occurred while calling the API: {ex.Message}");

    //            if (ex.InnerException != null)
    //            {
    //                Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            Console.WriteLine($"An error occurred while calling the API: {ex.Message}");
    //        }
    //    }
    //}
}
