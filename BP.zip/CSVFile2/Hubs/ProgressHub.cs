﻿
namespace CSVFileUpload.Hubs;
using Microsoft.AspNetCore.SignalR;

public class ProgressHub : Hub
{
   
    public async Task SendProgressUpdate(int progress)
    {
        await Clients.All.SendAsync("ReceiveProgress", progress);
    }

    public ProgressHub()
    {
        Console.WriteLine("ProgressHub created!");
    }

}
