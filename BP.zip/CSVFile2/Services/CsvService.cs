﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CSVFileDAL;
using CSVFileDAL.Models;
using CsvHelper;

namespace CSVFileUpload.Services;

public class CsvService : ICSVService
{
    

    

    public List<T> ReadCSV<T>(Stream file)
    {
        var reader = new StreamReader(file);
        var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

        var records = csv.GetRecords<T>().ToList();

        return records;
    }
    

}

